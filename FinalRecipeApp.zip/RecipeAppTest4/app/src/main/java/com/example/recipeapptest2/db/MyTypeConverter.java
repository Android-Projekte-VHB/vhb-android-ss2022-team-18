package com.example.recipeapptest2.db;

import android.util.Log;

import androidx.room.TypeConverter;

import java.util.ArrayList;

public class MyTypeConverter {

    @androidx.room.TypeConverter
    public static String toString(ArrayList<String> strings){
        String string = "";
        for(String s : strings){
            string += (s + "|");
        }
        return string;
    }

    @androidx.room.TypeConverter
    public static ArrayList<String> toStringArray(String string){
        ArrayList<String> stringArray = new ArrayList<>();
        for(String s : string.split("|")){
            stringArray.add(s);
        }
        return stringArray;
    }

}
