package com.example.recipeapptest2.RecipeData.RandomRecipes;

import java.util.ArrayList;

public class AnalyzedInstruction {
    public String name;
    public ArrayList<Step> steps;
}
