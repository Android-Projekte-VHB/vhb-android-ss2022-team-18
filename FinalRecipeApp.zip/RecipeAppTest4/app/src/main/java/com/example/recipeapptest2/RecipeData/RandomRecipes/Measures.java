package com.example.recipeapptest2.RecipeData.RandomRecipes;

public class Measures {
    public Us us;
    public Metric metric;
}
