package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class Nutrient {
    public String name;
    public double amount;
    public String unit;
    public double percentOfDailyNeeds;
}
