package com.example.recipeapptest2;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.example.recipeapptest2.Fragments.FavoritesFragment;
import com.example.recipeapptest2.Fragments.HomeFragment;
import com.example.recipeapptest2.Fragments.ShoppingListFragment;
import com.example.recipeapptest2.Fragments.TimerFragment;
import com.example.recipeapptest2.Listeners.ComplexRecipeSearchListener;
import com.example.recipeapptest2.Listeners.RandomRecipesResponseListener;
import com.example.recipeapptest2.Listeners.RecipeInfoResponseListener;
import com.example.recipeapptest2.Listeners.ShoppingListResponseListener;

import com.example.recipeapptest2.Manager.FavouritesListManager;
import com.example.recipeapptest2.Manager.ShoppingListManager;
import com.example.recipeapptest2.RecipeData.ComplexSearch.ComplexRecipesApiResponse;
import com.example.recipeapptest2.RecipeData.RandomRecipes.RandomRecipeData;
import com.example.recipeapptest2.RecipeData.RandomRecipes.RandomRecipesApiResponse;
import com.example.recipeapptest2.RecipeData.RecipeInfo.RecipeInfoApiResponse;


import com.example.recipeapptest2.api.RecipesRequest;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ShoppingListResponseListener , FavouritesListManager.ListManager, ShoppingListManager.ListManager {

    HomeFragment homeFragment;
    FavoritesFragment favoritesFragment;
    ShoppingListFragment shoppingListFragment;
    TimerFragment timerFragment;

    ArrayList<Recipe> currentRecipeList;
    List<Product> shoppingList;
    List<Recipe> favouriteRecipesList;

    FavouritesListManager favouritesListManager;
    ShoppingListManager shoppingListManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setupManager();
        setupLists();
        setupBottomNavigationBar();
        setUpData();
    }

    private void setupManager(){
        favouritesListManager = new FavouritesListManager(getApplicationContext(), this);
        shoppingListManager = new ShoppingListManager(getApplicationContext(), this);}

    private void setupLists(){
        currentRecipeList = new ArrayList<>();
        shoppingList = new ArrayList<>();
        favouriteRecipesList = new ArrayList<>();
    }

    private void setUpData(){
        updateFavRecipes();
        newRandomRecipes();
    }

    private void newRandomRecipes(){
        RecipesRequest requestRandomRecipes = new RecipesRequest(this);
        requestRandomRecipes.getRandomRecipes(listener);
    }

    private void setupBottomNavigationBar(){
        BottomNavigationView bottomNavigationView;
        homeFragment = new HomeFragment();
        favoritesFragment = new FavoritesFragment();
        shoppingListFragment = new ShoppingListFragment();
        shoppingListFragment.getListener(this);
        timerFragment = new TimerFragment();
        setFragment(homeFragment);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        setFragment(homeFragment);
                        newRandomRecipes();
                        updateRecipesFragment();
                        return true;
                    case R.id.favorites:
                        setFragment(favoritesFragment);
                        favoritesFragment.update(favouriteRecipesList);
                        return true;
                    case R.id.shoppingList:
                        setFragment(shoppingListFragment);
                        shoppingList = shoppingListManager.getShoppingList();
                        shoppingListFragment.updateList(shoppingList);
                        return true;
                    case R.id.timer:
                        setFragment(timerFragment);
                        return true;
                }
                return false;
            }
        });
    }

    private void updateRecipesFragment(){
      homeFragment.updateList(currentRecipeList);
    }

    private void setFragment(Fragment fragment){
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout, fragment).commit();
    }
    private void updateFavRecipes(){
        favouriteRecipesList = favouritesListManager.getFavouritesRecipesList();
        favoritesFragment.update(favouriteRecipesList);
    }

    private void getRecipesData(String query, String cuisine, String diet, String type, String intolerances) {
        RecipesRequest requestRecipes = new RecipesRequest(this);
        requestRecipes.getSpecificRecipes(recipeslistener, query, cuisine, diet, type, intolerances);
    }

    private RandomRecipesResponseListener listener = new RandomRecipesResponseListener() {
        @Override
        public void didFetch(RandomRecipesApiResponse response, String message) {
            for(int i = 0; i < response.recipes.size(); i++){
               RecipesRequest request = new RecipesRequest(MainActivity.this);
               request.getRecipeInfo(recipeInfoListener, response.recipes.get(i).id);
            }
            updateRecipesFragment();
        }
        @Override
        public void error(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }
    };

    private ComplexRecipeSearchListener recipeslistener = new ComplexRecipeSearchListener() {
        @Override
        public void didFetch(ComplexRecipesApiResponse response, String message) {
            for(int i = 0; i < response.results.size(); i++){
                RecipesRequest recipeInfo = new RecipesRequest(MainActivity.this);
                recipeInfo.getRecipeInfo(recipeInfoListener, response.results.get(i).id);
            }
        }
        @Override
        public void error(String message) {
            Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
        }
    };

    private RecipeInfoResponseListener recipeInfoListener = new RecipeInfoResponseListener() {
        @Override
        public void didFetch(RecipeInfoApiResponse response, String message) {
            ArrayList<String> ingredients = new ArrayList<>();
            ArrayList<String> ingredientsImage = new ArrayList<>();
            for(int j = 0; j < response.extendedIngredients.size(); j++){
                ingredients.add(response.extendedIngredients.get(j).original);
                ingredientsImage.add(response.extendedIngredients.get(j).image);
            }
            Boolean liked = false;
            Recipe recipe = new Recipe(response.title, response.image,  Double.toString(response.nutrition.nutrients.get(0).amount),
                    Integer.toString(response.readyInMinutes), Integer.toString(response.servings),
                    ingredients, ingredientsImage, response.instructions, liked );
            currentRecipeList.add(recipe);
        }
        @Override
        public void error(String message) {
        }
    };

    @Override
    public void onButtonClicked(Product product) {
       shoppingListManager.addProduct(product);
       shoppingListManager.requestUpdate();
        Toast.makeText(this, "product added", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onListUpdated() {
    }

    private void checkLikedStatus(Recipe recipe, Boolean oldStatus){
        if(recipe.liked){
            if(!oldStatus) {
                favouritesListManager.addRecipe(recipe);
                updateFavRecipes();
            }
        }else{
            if(oldStatus){
                favouritesListManager.deleteRecipe(recipe);
                updateFavRecipes();
            }
        }
    }

    private void checkIfProductsAdded(ArrayList<String> list){
        if(list.size() > 0 ){
            for(int i = 0; i < list.size(); i ++ ){
                Product product = new Product(list.get(i), "1");
                shoppingListManager.addProduct(product);
                shoppingListManager.requestUpdate();
            }
        }
    }

    private void checkData(Intent data){
        Recipe recipe = data.getParcelableExtra("recipe");
        Boolean oldStatus = data.getExtras().getBoolean("LikedStatusBefore");
        ArrayList<String> ingredientsList = data.getStringArrayListExtra("ingredientList");
        checkLikedStatus(recipe, oldStatus);
        checkIfProductsAdded(ingredientsList);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            if(resultCode == RESULT_OK){
                currentRecipeList.clear();
                String query = data.getStringExtra("query");
                String cuisine = data.getStringExtra("cuisine");
                String diet = data.getStringExtra("diet");
                String type = data.getStringExtra("type");
                String intolerance = data.getStringExtra("intolerance");
                getRecipesData(query, cuisine, diet, type, intolerance);

            }
        }
        updateRecipesFragment();
        if(requestCode == 2){
            if(resultCode == RESULT_OK){
               checkData(data);
            }
        }

        if(requestCode == 3){
            if(resultCode == RESULT_OK){
                setFragment(favoritesFragment);
                checkData(data);
            }
        }
    }
}
