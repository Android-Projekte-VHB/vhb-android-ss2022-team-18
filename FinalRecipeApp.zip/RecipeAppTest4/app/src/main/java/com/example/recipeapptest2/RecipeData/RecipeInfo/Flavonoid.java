package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class Flavonoid {
    public String name;
    public double amount;
    public String unit;
}
