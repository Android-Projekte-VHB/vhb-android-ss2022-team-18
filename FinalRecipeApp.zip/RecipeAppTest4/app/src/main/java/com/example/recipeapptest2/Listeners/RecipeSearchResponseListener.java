package com.example.recipeapptest2.Listeners;

import java.util.ArrayList;

public interface RecipeSearchResponseListener {
    void onButtonClicked(String tags);
}
