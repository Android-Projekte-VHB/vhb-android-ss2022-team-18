package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.RecipeData.Nutrition.NutritionApiResponse;

public interface NutritionResponseListener {
    void didFetch(NutritionApiResponse response, String message);
    void error(String message);
}
