package com.example.recipeapptest2.RecipeData.Nutrition;

public class Good {
    public String title;
    public String amount;
    public boolean indented;
    public double percentOfDailyNeeds;
}
