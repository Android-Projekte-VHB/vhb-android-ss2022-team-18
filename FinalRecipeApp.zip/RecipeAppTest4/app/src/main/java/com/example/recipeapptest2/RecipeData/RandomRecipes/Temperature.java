package com.example.recipeapptest2.RecipeData.RandomRecipes;

public class Temperature {
    public double number;
    public String unit;
}
