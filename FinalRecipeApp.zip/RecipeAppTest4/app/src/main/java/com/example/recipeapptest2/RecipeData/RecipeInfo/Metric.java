package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;
}
