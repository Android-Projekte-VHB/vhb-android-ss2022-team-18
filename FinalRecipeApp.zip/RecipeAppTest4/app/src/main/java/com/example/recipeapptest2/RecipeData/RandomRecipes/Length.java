package com.example.recipeapptest2.RecipeData.RandomRecipes;

public class Length {
    public int number;
    public String unit;
}
