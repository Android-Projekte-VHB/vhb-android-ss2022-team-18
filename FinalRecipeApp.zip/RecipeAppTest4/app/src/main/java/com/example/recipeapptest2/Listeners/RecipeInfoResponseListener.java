package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.RecipeData.RecipeInfo.RecipeInfoApiResponse;

public interface RecipeInfoResponseListener {
    void didFetch(RecipeInfoApiResponse response, String message);
    void error(String message);
}
