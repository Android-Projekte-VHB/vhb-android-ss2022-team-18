package com.example.recipeapptest2.RecipeData.ComplexSearch;

import com.example.recipeapptest2.RecipeData.ComplexSearch.ComplexRecipeData;

import java.util.ArrayList;

public class ComplexRecipesApiResponse {

    public ArrayList<ComplexRecipeData> results;
    public int offset;
    public int number;
    public int totalResults;
}
