package com.example.recipeapptest2.RecipeData.RandomRecipes;


import com.example.recipeapptest2.RecipeData.RandomRecipes.RandomRecipeData;

import java.util.ArrayList;

public class RandomRecipesApiResponse {
    public ArrayList<RandomRecipeData> recipes;
}

