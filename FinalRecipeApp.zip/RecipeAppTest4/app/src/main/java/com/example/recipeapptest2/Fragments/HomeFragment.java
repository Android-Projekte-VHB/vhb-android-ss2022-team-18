package com.example.recipeapptest2.Fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;

import com.example.recipeapptest2.Adapters.RandomRecipeAdapter;
import com.example.recipeapptest2.Listeners.RecyclerViewListResponseListener;
import com.example.recipeapptest2.MainActivity;
import com.example.recipeapptest2.R;
import com.example.recipeapptest2.Recipe;
import com.example.recipeapptest2.RecipeActivity;
import com.example.recipeapptest2.RecipeSearchActivity;

import java.util.ArrayList;


public class HomeFragment extends Fragment implements RecyclerViewListResponseListener {

    ImageButton button;
    RecyclerView recyclerView;
    RandomRecipeAdapter adapter;
    ArrayList<Recipe> list;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupButton(view);
        list = new ArrayList<>();
        recyclerView = view.findViewById(R.id.homeRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setHasFixedSize(true);
        adapter = new RandomRecipeAdapter(getContext(), list, this);
        recyclerView.setAdapter(adapter);
    }

    private void setupButton(View view) {
        button = view.findViewById(R.id.search_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newIntent = new Intent(getActivity(), RecipeSearchActivity.class);
                getActivity().startActivityForResult(newIntent, 1);
            }
        });
    }

    public void updateList(ArrayList<Recipe> newList) {
        adapter.updateList(newList);
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onItemClicked(Recipe recipe) {
        Intent newIntent = new Intent(getActivity(), RecipeActivity.class);
        newIntent.putExtra("recipe", recipe);
        getActivity().startActivityForResult(newIntent, 2);
    }
}
