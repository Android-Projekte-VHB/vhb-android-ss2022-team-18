package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.RecipeData.ComplexSearch.ComplexRecipesApiResponse;


public interface ComplexRecipeSearchListener {
    void didFetch(ComplexRecipesApiResponse response, String message);
    void error(String message);
}
