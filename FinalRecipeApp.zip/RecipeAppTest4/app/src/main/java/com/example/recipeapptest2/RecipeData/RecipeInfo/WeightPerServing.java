package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class WeightPerServing {
    public int amount;
    public String unit;
}
