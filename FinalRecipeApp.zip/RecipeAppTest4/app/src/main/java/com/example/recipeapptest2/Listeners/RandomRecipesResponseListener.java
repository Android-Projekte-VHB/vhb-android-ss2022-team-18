package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.RecipeData.RandomRecipes.RandomRecipesApiResponse;

public interface RandomRecipesResponseListener {
    void didFetch(RandomRecipesApiResponse response, String message);
    void error(String message);
}
