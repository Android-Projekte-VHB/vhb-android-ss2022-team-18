package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.Recipe;

public interface RecyclerViewListResponseListener {
    void onItemClicked(Recipe recipe);
}
