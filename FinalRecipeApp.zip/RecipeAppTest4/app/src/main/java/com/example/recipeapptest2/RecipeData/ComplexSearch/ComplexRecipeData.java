package com.example.recipeapptest2.RecipeData.ComplexSearch;

public class ComplexRecipeData {
    public int id;
    public String title;
    public String image;
    public String imageType;
}
