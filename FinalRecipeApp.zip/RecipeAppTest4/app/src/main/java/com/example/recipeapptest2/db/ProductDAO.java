package com.example.recipeapptest2.db;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.recipeapptest2.Product;
import com.example.recipeapptest2.Recipe;

import java.util.List;

@Dao
public interface ProductDAO {

    @Insert
    void addProduct(Product product);

    @Delete
    void deleteProduct(Product product);

    @Query("SELECT * FROM shoppingList")
    List<Product> getAllProducts();

    @Query("DELETE FROM shoppingList")
    void deleteAll();
}
