package com.example.recipeapptest2.TimerData.broadcast;

public interface TimerBroadcastListener {
    void onTimerUpdated(int remainingTimeInSeconds);

    void onTimerDone();

    void onTimerStopped();
}
