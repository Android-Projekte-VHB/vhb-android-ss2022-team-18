package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class Property {
}
