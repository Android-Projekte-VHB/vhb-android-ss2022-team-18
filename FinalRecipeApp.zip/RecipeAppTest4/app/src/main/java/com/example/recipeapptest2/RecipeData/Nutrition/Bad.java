package com.example.recipeapptest2.RecipeData.Nutrition;

public class Bad {
    public String title;
    public String amount;
    public boolean indented;
    public double percentOfDailyNeeds;
}
