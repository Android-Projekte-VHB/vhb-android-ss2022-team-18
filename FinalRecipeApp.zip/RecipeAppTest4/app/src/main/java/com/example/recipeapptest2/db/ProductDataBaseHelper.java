package com.example.recipeapptest2.db;

import android.content.Context;

import androidx.room.Room;
import androidx.room.migration.Migration;

import com.example.recipeapptest2.Product;
import java.util.ArrayList;

public class ProductDataBaseHelper {

    private static final String DATABASE_NAME = "products-db";

    private DataBase dataBase;

    public ProductDataBaseHelper(Context context) {
        dataBase = DataBase.getDatabase(context, DATABASE_NAME);
    }

    public void addProduct(Product product){
        dataBase.productDAO().addProduct(product);
    }

    public void deleteProduct(Product product){
        dataBase.productDAO().deleteProduct(product);

    }

    public ArrayList<Product> getShoppingList(){
        return new ArrayList<Product>(dataBase.productDAO().getAllProducts());
    }

    public void deleteAll(){
        dataBase.recipeDAO().deleteAll();
    }

}
