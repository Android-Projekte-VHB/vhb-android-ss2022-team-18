package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.Product;

import java.util.ArrayList;

public interface ShoppingListResponseListener {
    void onButtonClicked(Product product);
}
