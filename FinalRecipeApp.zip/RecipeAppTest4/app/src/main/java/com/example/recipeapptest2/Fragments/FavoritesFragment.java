package com.example.recipeapptest2.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recipeapptest2.Adapters.FavouritesListAdapter;
import com.example.recipeapptest2.Listeners.RecyclerViewListResponseListener;
import com.example.recipeapptest2.Manager.FavouritesListManager;
import com.example.recipeapptest2.R;
import com.example.recipeapptest2.Recipe;
import com.example.recipeapptest2.RecipeActivity;

import java.util.List;

public class FavoritesFragment extends Fragment implements RecyclerViewListResponseListener,  FavouritesListManager.ListManager {


    FavouritesListAdapter favouritesListAdapter;
    RecyclerView recyclerView;
    List<Recipe> list;
    FavouritesListManager manager;



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.fragment_favorites, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        manager = new FavouritesListManager(getContext(), this);
        recyclerView =  (RecyclerView) view.findViewById(R.id.favoritesRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        favouritesListAdapter = new FavouritesListAdapter( this);
        favouritesListAdapter.updateList(list);
        recyclerView.setAdapter(favouritesListAdapter);
    }

    @Override
    public void onResume() {
        super.onResume();
        favouritesListAdapter.updateList(list);
    }

    public void update(List<Recipe> newList){
        list = newList;
    }


    @Override
    public void onItemClicked(Recipe recipeName) {
        Recipe recipe = manager.getRecipe(recipeName.title);
        Log.d("test", recipe.ingredients + "");
        Intent newIntent = new Intent( getActivity() , RecipeActivity.class);
        newIntent.putExtra("recipe", recipe);
        startActivityForResult(newIntent, 3);
    }

    @Override
    public void onListUpdated() {

    }
}