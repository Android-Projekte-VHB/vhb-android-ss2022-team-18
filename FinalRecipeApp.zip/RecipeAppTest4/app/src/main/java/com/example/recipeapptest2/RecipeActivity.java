package com.example.recipeapptest2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recipeapptest2.Adapters.IngredientsListAdapter;
import com.example.recipeapptest2.Listeners.IngredientsClickListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class RecipeActivity extends AppCompatActivity implements IngredientsClickListener {

    RecyclerView recyclerView;
    IngredientsListAdapter adapter;
    Recipe recipe;
    Boolean oldLikedStatus;
    Button favouriteButton;
    ArrayList<String> shoppingList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_recipe_details);
        shoppingList = new ArrayList<>();
        setupUI();
        setupButtons();
        setLikedButtonColor();
    }

    private void setLikedButtonColor() {
        if (oldLikedStatus) {
            favouriteButton.setBackgroundResource(R.drawable.ic_baseline_favorite_red_24);
        } else {
            favouriteButton.setBackgroundResource(R.drawable.ic_baseline_favorite_grey_24);
        }
    }

    private void setupButtons() {
        Button backButton = findViewById(R.id.back_button);
        favouriteButton = findViewById(R.id.favourite_button);
        favouriteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!recipe.liked) {
                    favouriteButton.setBackgroundResource(R.drawable.ic_baseline_favorite_red_24);
                    recipe.liked = true;
                }else{
                    favouriteButton.setBackgroundResource(R.drawable.ic_baseline_favorite_grey_24);
                    recipe.liked = false;
                }
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newIntent = new Intent(RecipeActivity.this, MainActivity.class);
                newIntent.putExtra("recipe", recipe);
                newIntent.putExtra("LikedStatusBefore", oldLikedStatus);
                if(shoppingList.size() > 0) {
                    newIntent.putExtra("ingredientList", shoppingList);
                }
                setResult(RESULT_OK, newIntent);
                finish();
            }
        });
    }

    private void setupUI() {
        Intent intent = getIntent();
        recipe = intent.getParcelableExtra("recipe");

        TextView recipeTitle = findViewById(R.id.recipe_title);
        recipeTitle.setText(recipe.title);

        ImageView recipeImage = findViewById(R.id.recipe_image);
        Picasso.get().load(recipe.image).into(recipeImage);

        TextView recipeTime = findViewById(R.id.time_amount);
        recipeTime.setText(recipe.time + "min");

        TextView recipeServings = findViewById(R.id.servings_amount);
        recipeServings.setText(recipe.servings);

        TextView recipeDescription = findViewById(R.id.recipe_description);
        recipeDescription.setText(recipe.instruction);

        TextView calories = findViewById(R.id.calories_amount);
        calories.setText(recipe.calories);

        recyclerView = findViewById(R.id.ingredients_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new GridLayoutManager(RecipeActivity.this, 1));
        adapter = new IngredientsListAdapter(recipe.ingredients, recipe.ingredientsImages, this);
        recyclerView.setAdapter(adapter);

        oldLikedStatus = recipe.liked;
    }


    @Override
    public void onClick(int i) {
        shoppingList.add(recipe.ingredients.get(i));
        Toast.makeText(this, "Product added", Toast.LENGTH_LONG).show();
    }
}
