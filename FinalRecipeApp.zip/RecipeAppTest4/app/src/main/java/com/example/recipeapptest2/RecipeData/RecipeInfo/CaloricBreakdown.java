package com.example.recipeapptest2.RecipeData.RecipeInfo;

public class CaloricBreakdown {
    public double percentProtein;
    public double percentFat;
    public double percentCarbs;
}
