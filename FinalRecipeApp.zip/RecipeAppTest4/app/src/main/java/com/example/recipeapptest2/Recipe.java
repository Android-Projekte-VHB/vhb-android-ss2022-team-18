package com.example.recipeapptest2;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.ArrayList;

@Entity(tableName = "recipe")
public class Recipe implements Parcelable{

    @PrimaryKey
    @NonNull
    public String title;
    public String image;
    public String calories;
    public String time;
    public String servings;
    public ArrayList<String> ingredients;
    public ArrayList<String> ingredientsImages;
    public String instruction;
    public Boolean liked;

    public Recipe(String title, String image, String calories, String time, String servings, ArrayList<String>ingredients,
                  ArrayList<String>ingredientsImages, String instruction, Boolean liked ){

        this.title = title;
        this.image = image;
        this.calories = calories;
        this.time = time;
        this.servings = servings;
        this.ingredients = ingredients;
        this.ingredientsImages = ingredientsImages;
        this.instruction = instruction;
        this.liked = liked;

    }


    protected Recipe(Parcel in) {
        title = in.readString();
        image = in.readString();
        calories = in.readString();
        time = in.readString();
        servings = in.readString();
        ingredients = in.createStringArrayList();
        ingredientsImages = in.createStringArrayList();
        instruction = in.readString();
        byte tmpLiked = in.readByte();
        liked = tmpLiked == 0 ? null : tmpLiked == 1;
    }

    public static final Creator<Recipe> CREATOR = new Creator<Recipe>() {
        @Override
        public Recipe createFromParcel(Parcel in) {
            return new Recipe(in);
        }

        @Override
        public Recipe[] newArray(int size) {
            return new Recipe[size];
        }
    };

    public Boolean getLiked(){
        return liked;
    }

    public void setLiked(){
        liked = true;
    }

    public void setNotLiked(){
        liked = false;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(title);
        parcel.writeString(image);
        parcel.writeString(calories);
        parcel.writeString(time);
        parcel.writeString(servings);
        parcel.writeStringList(ingredients);
        parcel.writeStringList(ingredientsImages);
        parcel.writeString(instruction);
        parcel.writeByte((byte) (liked == null ? 0 : liked ? 1 : 2));
    }
}
