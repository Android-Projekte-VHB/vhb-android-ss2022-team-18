package com.example.recipeapptest2.Listeners;

import com.example.recipeapptest2.Product;

public interface IngredientsClickListener {
    void onClick(int position);
}
