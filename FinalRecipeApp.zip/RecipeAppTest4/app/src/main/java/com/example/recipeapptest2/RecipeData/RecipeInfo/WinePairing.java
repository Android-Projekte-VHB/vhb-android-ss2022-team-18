package com.example.recipeapptest2.RecipeData.RecipeInfo;

import java.util.ArrayList;

public class WinePairing {
    public ArrayList<Object> pairedWines;
    public String pairingText;
    public ArrayList<Object> productMatches;
}
