package com.example.recipeapptest2.RecipeData.RandomRecipes;

import com.example.recipeapptest2.RecipeData.RandomRecipes.Equipment;
import com.example.recipeapptest2.RecipeData.RandomRecipes.Length;
import com.example.recipeapptest2.RecipeData.RecipeInfo.Ingredient;

import java.util.ArrayList;

public class Step {
    public int number;
    public String step;
    public ArrayList<Ingredient> ingredients;
    public ArrayList<Equipment> equipment;
    public Length length;
}
